
import React from 'react';
import { ChartBarIcon, ClockIcon, TagIcon, PlusIcon, XMarkIcon } from './ui/icons';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  setActiveView: (view: string) => void;
  activeView: string;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, setActiveView, activeView }) => {
  const navItems = [
    { id: 'form', label: 'Registrar Gasto', icon: <PlusIcon /> },
    { id: 'stats', label: 'Estadísticas', icon: <ChartBarIcon /> },
    { id: 'history', label: 'Historial', icon: <ClockIcon /> },
    { id: 'categories', label: 'Listado de Categorías', icon: <TagIcon /> },
  ];

  const baseItemClass = "flex items-center p-3 my-1 rounded-lg cursor-pointer transition-colors duration-200";
  const activeItemClass = "bg-primary-500 text-white shadow-lg";
  const inactiveItemClass = "text-gray-300 hover:bg-primary-900";

  return (
    <>
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        } lg:hidden`}
        onClick={onClose}
      ></div>
      <aside
        className={`fixed top-0 left-0 h-full bg-gray-800 text-white w-72 shadow-xl z-40 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 lg:static lg:h-screen`}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h1 className="text-2xl font-bold text-gray-300">Control de Gastos</h1>
          <button onClick={onClose} className="lg:hidden text-gray-300 hover:text-white">
            <XMarkIcon />
          </button>
        </div>
        <nav className="p-4">
          <ul>
            {navItems.map(item => (
              <li key={item.id} onClick={() => { setActiveView(item.id); onClose(); }}>
                <a className={`${baseItemClass} ${activeView === item.id ? activeItemClass : inactiveItemClass}`}>
                  <span className="mr-3">{item.icon}</span>
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;