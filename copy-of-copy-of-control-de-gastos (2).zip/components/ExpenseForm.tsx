
import React, { useState } from 'react';
import { Category, Expense } from '../types';

interface ExpenseFormProps {
  categories: Category[];
  addExpense: (expense: Omit<Expense, 'id' | 'date'>) => void;
}

const ExpenseForm: React.FC<ExpenseFormProps> = ({ categories, addExpense }) => {
  const [concept, setConcept] = useState('');
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState<string>(categories[0]?.id || '');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!concept || !amount || !categoryId) {
      setError('Todos los campos son obligatorios.');
      setSuccess('');
      return;
    }
    const amountNumber = parseFloat(amount);
    if (isNaN(amountNumber) || amountNumber <= 0) {
      setError('El monto debe ser un número positivo.');
      setSuccess('');
      return;
    }

    addExpense({
      concept,
      amount: amountNumber,
      categoryId,
    });

    setConcept('');
    setAmount('');
    setError('');
    setSuccess('¡Gasto registrado con éxito!');
    setTimeout(() => setSuccess(''), 3000); // Clear success message after 3 seconds
  };

  return (
    <div className="bg-gray-800 p-8 shadow-lg w-full max-w-lg mx-auto">
      <h2 className="text-3xl font-bold text-center mb-2 text-white">Registrar Gasto</h2>
      <p className="text-center text-gray-400 mb-8">Anota tus gastos para tener un mejor control.</p>
      
      {error && <div className="bg-red-900 border border-red-400 text-red-200 px-4 py-3 relative mb-4" role="alert">{error}</div>}
      {success && <div className="bg-green-900 border border-green-400 text-green-200 px-4 py-3 relative mb-4" role="alert">{success}</div>}
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="concept" className="block text-sm font-medium text-gray-300 mb-1">Concepto de Gasto</label>
          <input
            type="text"
            id="concept"
            value={concept}
            onChange={(e) => setConcept(e.target.value)}
            placeholder="Ej: Almuerzo de trabajo"
            className="w-full px-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
          />
        </div>
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-300 mb-1">Monto en S/.</label>
          <div className="relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">S/.</span>
            <input
              type="number"
              id="amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              step="0.01"
              className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
            />
          </div>
        </div>
        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-300 mb-1">Categoría</label>
          <select
            id="category"
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            className="w-full px-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
          >
            <option value="" disabled>Selecciona una categoría</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
        </div>
        <p className="text-sm text-gray-400">
          La fecha del gasto se registrará como hoy: {new Date().toLocaleDateString('es-ES')}.
        </p>
        <button
          type="submit"
          className="w-full bg-gray-600 text-white font-bold py-3 px-4 hover:bg-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 transition duration-300 ease-in-out transform hover:scale-105"
        >
          Registrar
        </button>
      </form>
    </div>
  );
};

export default ExpenseForm;