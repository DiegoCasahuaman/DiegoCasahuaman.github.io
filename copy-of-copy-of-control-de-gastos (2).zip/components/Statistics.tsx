
import React, { useState, useMemo, useRef } from 'react';
import { Expense, Category } from '../types';
import { ChevronDownIcon } from './ui/icons';

interface StatisticsProps {
  expenses: Expense[];
  categories: Category[];
}

const getWeekNumber = (d: Date): string => {
    d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
    d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
    return `${d.getUTCFullYear()}-W${weekNo.toString().padStart(2, '0')}`;
};

const Statistics: React.FC<StatisticsProps> = ({ expenses, categories }) => {
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
    const todayISO = today.toISOString().split('T')[0];
    
    const [filters, setFilters] = useState({
        startDate: firstDayOfMonth,
        endDate: todayISO,
        timeUnit: 'Días',
        selectedCategories: [] as string[],
    });
    const [isDropdownOpen, setDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

     const handleCategoryChange = (categoryId: string) => {
        setFilters(prev => {
            const newSelected = prev.selectedCategories.includes(categoryId)
                ? prev.selectedCategories.filter(id => id !== categoryId)
                : [...prev.selectedCategories, categoryId];
            return { ...prev, selectedCategories: newSelected };
        });
    };

    const toggleSelectAllCategories = () => {
        if (filters.selectedCategories.length === categories.length) {
            setFilters(prev => ({...prev, selectedCategories: []}));
        } else {
            setFilters(prev => ({...prev, selectedCategories: categories.map(c => c.id)}));
        }
    }

    const chartData = useMemo(() => {
        const filtered = expenses.filter(e => {
            const expenseDate = e.date.split('T')[0];
            const isAfterStartDate = !filters.startDate || expenseDate >= filters.startDate;
            const isBeforeEndDate = !filters.endDate || expenseDate <= filters.endDate;
            const inCategory = filters.selectedCategories.length === 0 || filters.selectedCategories.includes(e.categoryId);
            return isAfterStartDate && isBeforeEndDate && inCategory;
        });

        const grouped = filtered.reduce((acc, expense) => {
            const date = new Date(expense.date);
            let key = '';
            switch(filters.timeUnit) {
                case 'Semanas':
                    key = getWeekNumber(date);
                    break;
                case 'Años':
                    key = date.getFullYear().toString();
                    break;
                case 'Días':
                default:
                    key = date.toISOString().split('T')[0];
                    break;
            }
            if (!acc[key]) acc[key] = 0;
            acc[key] += expense.amount;
            return acc;
        }, {} as Record<string, number>);

        return Object.entries(grouped)
            .map(([label, value]) => ({ label, value }))
            .sort((a,b) => a.label.localeCompare(b.label));

    }, [expenses, filters]);

    const maxValue = Math.max(0, ...chartData.map(d => d.value));
    const yAxisTopValue = maxValue > 0 ? Math.ceil(maxValue / 50) * 50 : 50;
    const yAxisLabels = Array.from({ length: (yAxisTopValue / 50) + 1 }, (_, i) => yAxisTopValue - (i * 50));

    const BarChart = () => (
        <div className="w-full h-96 flex">
            {/* Y-Axis Labels */}
            <div className="h-full flex flex-col justify-between text-right pr-2 text-xs text-gray-400">
                {yAxisLabels.map(label => (
                    <div key={label}>S/. {label}</div>
                ))}
            </div>

            {/* Chart Area */}
            <div className="flex-1 h-full bg-gray-700 p-4 relative">
                 {/* Grid Lines */}
                <div className="absolute top-0 left-4 right-4 h-full pointer-events-none">
                    {yAxisLabels.map((label, index) => (
                        index > 0 && 
                        <div 
                            key={`grid-${label}`}
                            className="absolute w-full border-t border-gray-600 border-dashed left-0"
                            style={{ 
                                top: `${(index * 100) / (yAxisLabels.length - 1)}%` 
                            }}
                        ></div>
                    ))}
                </div>

                {/* Bars Container */}
                <div className="w-full h-full flex items-end space-x-2 overflow-x-auto">
                    {chartData.map(({ label, value }, index) => {
                        const barHeight = yAxisTopValue > 0 ? (value / yAxisTopValue) * 100 : 0;
                        return (
                            <div key={index} className="h-full flex-1 min-w-[30px] flex flex-col items-center justify-end group relative z-10">
                                <div className="absolute bottom-full mb-2 w-max px-2 py-1 bg-gray-800 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                                    S/. {value.toFixed(2)}
                                </div>
                                <div 
                                    className="w-full bg-primary-500 hover:bg-primary-600 transition-all"
                                    style={{ height: `${barHeight}%` }}
                                ></div>
                                <span className="text-xs text-gray-400 mt-1 whitespace-nowrap transform -rotate-45 origin-center">{label}</span>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );

    return (
        <div className="bg-gray-800 p-4 sm:p-8 shadow-lg w-full mx-auto">
            <h2 className="text-3xl font-bold mb-6 text-white">Estadísticas de Gastos</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 p-4 bg-gray-700">
                <div>
                    <label htmlFor="startDate" className="block text-sm font-medium text-gray-300">Fecha Inicio</label>
                    <input type="date" name="startDate" value={filters.startDate} onChange={handleFilterChange} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition" />
                </div>
                <div>
                    <label htmlFor="endDate" className="block text-sm font-medium text-gray-300">Fecha Fin</label>
                    <input type="date" name="endDate" value={filters.endDate} onChange={handleFilterChange} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition" />
                </div>
                <div>
                    <label htmlFor="timeUnit" className="block text-sm font-medium text-gray-300">Unidades de Tiempo</label>
                    <select name="timeUnit" value={filters.timeUnit} onChange={handleFilterChange} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition">
                        <option>Días</option>
                        <option>Semanas</option>
                        <option>Años</option>
                    </select>
                </div>
                <div className="relative">
                    <label className="block text-sm font-medium text-gray-300">Categorías</label>
                    <button onClick={() => setDropdownOpen(!isDropdownOpen)} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition flex justify-between items-center text-left">
                        <span>{filters.selectedCategories.length === 0 ? 'Todo' : `${filters.selectedCategories.length} seleccionada(s)`}</span>
                        <ChevronDownIcon />
                    </button>
                    {isDropdownOpen && (
                        <div ref={dropdownRef} className="absolute z-10 w-full mt-1 bg-gray-800 border border-gray-600 shadow-lg max-h-60 overflow-y-auto">
                            <div className="px-4 py-2 border-b border-gray-700">
                                <label className="flex items-center space-x-2 cursor-pointer">
                                    <input type="checkbox" onChange={toggleSelectAllCategories} checked={filters.selectedCategories.length === categories.length} className="h-4 w-4 border-gray-300 text-primary-600 focus:ring-primary-500" />
                                    <span>Seleccionar Todo</span>
                                </label>
                            </div>
                            {categories.map(cat => (
                                <div key={cat.id} className="px-4 py-2">
                                    <label className="flex items-center space-x-2 cursor-pointer">
                                        <input type="checkbox" checked={filters.selectedCategories.includes(cat.id)} onChange={() => handleCategoryChange(cat.id)} className="h-4 w-4 border-gray-300 text-primary-600 focus:ring-primary-500" />
                                        <span>{cat.name}</span>
                                    </label>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            {chartData.length > 0 ? (
                <BarChart />
            ) : (
                <div className="w-full h-96 bg-gray-700 p-4 flex justify-center items-center">
                    <p className="text-gray-400">No hay datos para mostrar con los filtros seleccionados.</p>
                </div>
            )}
        </div>
    );
};

export default Statistics;