
import React, { useState } from 'react';
import { Category, Expense } from '../types';
import Modal from './ui/Modal';
import { PlusIcon, PencilIcon, TrashIcon } from './ui/icons';

interface CategoryManagerProps {
  categories: Category[];
  expenses: Expense[];
  addCategory: (name: string) => boolean;
  editCategory: (id: string, newName: string) => boolean;
  deleteCategory: (id: string, reassignToId?: string) => boolean;
}

const CategoryManager: React.FC<CategoryManagerProps> = ({ categories, expenses, addCategory, editCategory, deleteCategory }) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [modalState, setModalState] = useState<'add' | 'edit' | 'delete' | 'reassign' | null>(null);
  const [categoryName, setCategoryName] = useState('');
  const [reassignToId, setReassignToId] = useState<string>('');
  const [error, setError] = useState('');
  
  const openModal = (state: 'add' | 'edit' | 'delete') => {
    setError('');
    if ((state === 'edit' || state === 'delete') && !selectedCategoryId) {
      alert('Por favor, selecciona una categoría primero.');
      return;
    }
    if (state === 'edit') {
        const selectedCategory = categories.find(c => c.id === selectedCategoryId);
        setCategoryName(selectedCategory?.name || '');
    }
    if (state === 'delete') {
        const expensesExist = expenses.some(e => e.categoryId === selectedCategoryId);
        if (expensesExist) {
            const otherCategories = categories.filter(c => c.id !== selectedCategoryId);
            if(otherCategories.length > 0) {
              setReassignToId(otherCategories[0].id);
              setModalState('reassign');
            } else {
              alert('No puedes eliminar la única categoría que tiene gastos. Crea otra categoría primero.');
            }
        } else {
            setModalState('delete');
        }
        return;
    }

    setModalState(state);
  };

  const closeModal = () => {
    setModalState(null);
    setCategoryName('');
    setError('');
  };

  const handleAdd = () => {
    if (!addCategory(categoryName)) {
      setError('El nombre de la categoría no puede estar vacío o ya existe.');
    } else {
      closeModal();
    }
  };

  const handleEdit = () => {
    if (selectedCategoryId && !editCategory(selectedCategoryId, categoryName)) {
      setError('El nombre de la categoría no puede estar vacío o ya existe.');
    } else {
      closeModal();
    }
  };
  
  const handleDelete = () => {
    if (selectedCategoryId) {
        deleteCategory(selectedCategoryId);
        setSelectedCategoryId(null);
    }
    closeModal();
  };
  
  const handleReassignAndDelete = () => {
    if (selectedCategoryId && reassignToId) {
        deleteCategory(selectedCategoryId, reassignToId);
        setSelectedCategoryId(null);
    }
    closeModal();
  };

  return (
    <div className="bg-gray-800 p-8 shadow-lg w-full max-w-2xl mx-auto">
      <h2 className="text-3xl font-bold mb-6 text-white">Gestionar Categorías</h2>
      
      <div className="flex items-center space-x-2 mb-6">
        <button onClick={() => openModal('add')} className="flex items-center justify-center px-4 py-2 bg-primary-600 text-white hover:bg-primary-700 transition">
            <PlusIcon /> <span className="ml-2">Agregar</span>
        </button>
        <button onClick={() => openModal('edit')} className="flex items-center justify-center px-4 py-2 bg-yellow-500 text-white hover:bg-yellow-600 transition disabled:opacity-50" disabled={!selectedCategoryId}>
            <PencilIcon /> <span className="ml-1">Editar</span>
        </button>
        <button onClick={() => openModal('delete')} className="flex items-center justify-center px-4 py-2 bg-red-600 text-white hover:bg-red-700 transition disabled:opacity-50" disabled={!selectedCategoryId}>
            <TrashIcon /> <span className="ml-1">Eliminar</span>
        </button>
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
        {categories.map(category => (
          <div
            key={category.id}
            onClick={() => setSelectedCategoryId(category.id)}
            className={`p-4 cursor-pointer transition-all duration-200 border-2 ${selectedCategoryId === category.id ? 'bg-primary-900 border-primary-500 shadow-md' : 'bg-gray-700 border-transparent hover:border-primary-300'}`}
          >
            {category.name}
          </div>
        ))}
      </div>

      {/* Add/Edit Modal */}
      <Modal 
        isOpen={modalState === 'add' || modalState === 'edit'} 
        onClose={closeModal} 
        title={modalState === 'add' ? 'Agregar Categoría' : 'Editar Categoría'}
        footer={
            <div className="space-x-2 w-full flex justify-end">
                <button onClick={closeModal} className="px-4 py-2 bg-gray-600 hover:bg-gray-500">Cancelar</button>
                <button onClick={modalState === 'add' ? handleAdd : handleEdit} className="px-4 py-2 bg-primary-600 text-white hover:bg-primary-700">OK</button>
            </div>
        }
      >
        <label htmlFor="categoryName" className="block text-sm font-medium text-gray-300 mb-1">Nombre de la Categoría</label>
        <input
            id="categoryName"
            type="text"
            value={categoryName}
            onChange={(e) => setCategoryName(e.target.value)}
            className="w-full px-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
        />
        {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
      </Modal>

       {/* Delete Confirmation Modal */}
      <Modal
        isOpen={modalState === 'delete'}
        onClose={closeModal}
        title="Confirmar Eliminación"
        footer={
            <div className="space-x-2 w-full flex justify-end">
                <button onClick={closeModal} className="px-4 py-2 bg-gray-600 hover:bg-gray-500">Cancelar</button>
                <button onClick={handleDelete} className="px-4 py-2 bg-red-600 text-white hover:bg-red-700">Eliminar</button>
            </div>
        }
      >
        <p>¿Estás seguro de que quieres eliminar la categoría "{categories.find(c => c.id === selectedCategoryId)?.name}"?</p>
      </Modal>

       {/* Reassign and Delete Modal */}
      <Modal
        isOpen={modalState === 'reassign'}
        onClose={closeModal}
        title="Reasignar Gastos"
        footer={
            <div className="space-x-2 w-full flex justify-end">
                <button onClick={closeModal} className="px-4 py-2 bg-gray-600 hover:bg-gray-500">Cancelar</button>
                <button onClick={handleReassignAndDelete} className="px-4 py-2 bg-red-600 text-white hover:bg-red-700">OK</button>
            </div>
        }
      >
        <p className="mb-4">La categoría "{categories.find(c => c.id === selectedCategoryId)?.name}" tiene gastos registrados. Por favor, selecciona una nueva categoría para reasignarlos antes de eliminarla.</p>
        <label htmlFor="reassignCategory" className="block text-sm font-medium text-gray-300 mb-1">Reasignar a:</label>
        <select
            id="reassignCategory"
            value={reassignToId}
            onChange={(e) => setReassignToId(e.target.value)}
            className="w-full px-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
        >
            {categories.filter(c => c.id !== selectedCategoryId).map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
        </select>
      </Modal>
    </div>
  );
};

export default CategoryManager;