
import React, { useState, useEffect } from 'react';
import { Expense, Category } from '../types';
import Modal from './ui/Modal';

interface EditExpenseModalProps {
  expense: Expense;
  categories: Category[];
  onSave: (expense: Expense) => void;
  onClose: () => void;
}

const EditExpenseModal: React.FC<EditExpenseModalProps> = ({ expense, categories, onSave, onClose }) => {
  const [formData, setFormData] = useState({
    concept: expense.concept,
    amount: expense.amount.toString(),
    categoryId: expense.categoryId,
    date: expense.date.split('T')[0], // Format date to YYYY-MM-DD for the input
  });
  const [error, setError] = useState('');

  useEffect(() => {
    // Reset form data if the expense prop changes
    setFormData({
        concept: expense.concept,
        amount: expense.amount.toString(),
        categoryId: expense.categoryId,
        date: expense.date.split('T')[0],
    });
    setError('');
  }, [expense]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    if (!formData.concept || !formData.amount || !formData.categoryId || !formData.date) {
      setError('Todos los campos son obligatorios.');
      return;
    }
    const amountNumber = parseFloat(formData.amount);
    if (isNaN(amountNumber) || amountNumber <= 0) {
      setError('El monto debe ser un número positivo.');
      return;
    }

    // Combine date with a default time to create a full ISO string
    const updatedExpense: Expense = {
      ...expense,
      ...formData,
      amount: amountNumber,
      date: new Date(formData.date).toISOString(),
    };
    onSave(updatedExpense);
  };

  return (
    <Modal
      isOpen={true}
      onClose={onClose}
      title="Editar Gasto"
      footer={
        <div className="space-x-2 w-full flex justify-end">
          <button onClick={onClose} className="px-4 py-2 bg-gray-600 hover:bg-gray-500">
            Cancelar
          </button>
          <button onClick={handleSave} className="px-4 py-2 bg-primary-600 text-white hover:bg-primary-700">
            OK
          </button>
        </div>
      }
    >
      <div className="space-y-4">
        {error && <p className="text-red-500 text-sm">{error}</p>}
        <div>
          <label htmlFor="concept" className="block text-sm font-medium text-gray-300 mb-1">Concepto</label>
          <input
            type="text"
            id="concept"
            name="concept"
            value={formData.concept}
            onChange={handleChange}
            className="w-full px-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
          />
        </div>
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-gray-300 mb-1">Monto (S/.)</label>
           <div className="relative">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">S/.</span>
            <input
                type="number"
                id="amount"
                name="amount"
                value={formData.amount}
                onChange={handleChange}
                step="0.01"
                className="w-full pl-10 pr-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
            />
          </div>
        </div>
        <div>
          <label htmlFor="categoryId" className="block text-sm font-medium text-gray-300 mb-1">Categoría</label>
          <select
            id="categoryId"
            name="categoryId"
            value={formData.categoryId}
            onChange={handleChange}
            className="w-full px-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
          >
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-gray-300 mb-1">Fecha</label>
          <input
            type="date"
            id="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            className="w-full px-4 py-2 bg-gray-700 border border-gray-600 focus:ring-primary-500 focus:border-primary-500 transition"
          />
        </div>
      </div>
    </Modal>
  );
};

export default EditExpenseModal;