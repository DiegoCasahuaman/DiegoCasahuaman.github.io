
import React, { useState, useMemo, useRef } from 'react';
import { Expense, Category } from '../types';
import { ArrowUpIcon, ArrowDownIcon, DocumentArrowDownIcon, ChevronDownIcon } from './ui/icons';

declare const XLSX: any;

interface HistoryProps {
  expenses: Expense[];
  categories: Category[];
  onEditExpense: (expense: Expense) => void;
}

const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('es-ES');
const formatCurrency = (amount: number) => `S/. ${amount.toFixed(2)}`;

const History: React.FC<HistoryProps> = ({ expenses, categories, onEditExpense }) => {
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
    const todayISO = today.toISOString().split('T')[0];
    
    const [filters, setFilters] = useState({
        startDate: firstDayOfMonth,
        endDate: todayISO,
        selectedCategories: [] as string[],
        concept: ''
    });
    const [sort, setSort] = useState<{ key: keyof Expense | 'categoryName', order: 'asc' | 'desc' }>({ key: 'date', order: 'desc' });
    const [isDropdownOpen, setDropdownOpen] = useState(false);
    const dropdownRef = useRef<HTMLDivElement>(null);

    const categoriesMap = useMemo(() => {
        return categories.reduce((acc, cat) => {
            acc[cat.id] = cat.name;
            return acc;
        }, {} as Record<string, string>);
    }, [categories]);

    const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleCategoryChange = (categoryId: string) => {
        setFilters(prev => {
            const newSelected = prev.selectedCategories.includes(categoryId)
                ? prev.selectedCategories.filter(id => id !== categoryId)
                : [...prev.selectedCategories, categoryId];
            return { ...prev, selectedCategories: newSelected };
        });
    };

    const toggleSelectAllCategories = () => {
        if (filters.selectedCategories.length === categories.length) {
            setFilters(prev => ({...prev, selectedCategories: []}));
        } else {
            setFilters(prev => ({...prev, selectedCategories: categories.map(c => c.id)}));
        }
    }

    const filteredAndSortedExpenses = useMemo(() => {
        const expenseWithCategoryName = expenses.map(e => ({ ...e, categoryName: categoriesMap[e.categoryId] || 'Sin categoría' }));

        let filtered = expenseWithCategoryName.filter(e => {
            const expenseDate = e.date.split('T')[0];
            const isAfterStartDate = !filters.startDate || expenseDate >= filters.startDate;
            const isBeforeEndDate = !filters.endDate || expenseDate <= filters.endDate;
            const inCategory = filters.selectedCategories.length === 0 || filters.selectedCategories.includes(e.categoryId);
            const matchesConcept = e.concept.toLowerCase().includes(filters.concept.toLowerCase());
            return isAfterStartDate && isBeforeEndDate && inCategory && matchesConcept;
        });
        
        filtered.sort((a, b) => {
            const valA = a[sort.key as keyof typeof a];
            const valB = b[sort.key as keyof typeof b];
            if (valA < valB) return sort.order === 'asc' ? -1 : 1;
            if (valA > valB) return sort.order === 'asc' ? 1 : -1;
            return 0;
        });

        // Map back to original expense objects to pass to onEditExpense
        const sortedIds = filtered.map(e => e.id);
        return sortedIds.map(id => expenses.find(e => e.id === id)).filter(Boolean) as Expense[];

    }, [expenses, categoriesMap, filters, sort]);
    
    // Create a new memoized array for rendering that includes the categoryName
    const expensesToRender = useMemo(() => {
        return filteredAndSortedExpenses.map(e => ({
            ...e,
            categoryName: categoriesMap[e.categoryId] || 'Sin categoría'
        }));
    }, [filteredAndSortedExpenses, categoriesMap]);


    const handleSort = (key: keyof Expense | 'categoryName') => {
        setSort(prev => ({
            key,
            order: prev.key === key && prev.order === 'asc' ? 'desc' : 'asc'
        }));
    };

    const exportToXLSX = () => {
        const dataToExport = expensesToRender.map(e => ({
            'Concepto': e.concept,
            'Monto (S/.)': e.amount,
            'Categoría': e.categoryName,
            'Fecha': formatDate(e.date)
        }));
    
        const worksheet = XLSX.utils.json_to_sheet(dataToExport);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Gastos");
    
        const columnWidths = [
            { wch: 40 }, // Concepto
            { wch: 15 }, // Monto (S/.)
            { wch: 25 }, // Categoría
            { wch: 15 }  // Fecha
        ];
        worksheet['!cols'] = columnWidths;
    
        XLSX.writeFile(workbook, "historial_gastos.xlsx");
    };

    const SortableHeader: React.FC<{ sortKey: keyof Expense | 'categoryName', title: string }> = ({ sortKey, title }) => (
        <th scope="col" className="px-6 py-3">
            <div className="flex items-center cursor-pointer" onClick={() => handleSort(sortKey)}>
                {title}
                {sort.key === sortKey && (sort.order === 'asc' ? <ArrowUpIcon /> : <ArrowDownIcon />)}
            </div>
        </th>
    );

  return (
    <div className="bg-gray-800 p-4 sm:p-8 shadow-lg w-full mx-auto">
        <h2 className="text-3xl font-bold mb-6 text-white">Historial de Gastos</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 p-4 bg-gray-700">
            <div>
                <label htmlFor="startDate" className="block text-sm font-medium text-gray-300">Fecha Inicio</label>
                <input type="date" name="startDate" value={filters.startDate} onChange={handleFilterChange} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition" />
            </div>
            <div>
                <label htmlFor="endDate" className="block text-sm font-medium text-gray-300">Fecha Fin</label>
                <input type="date" name="endDate" value={filters.endDate} onChange={handleFilterChange} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition" />
            </div>
            <div className="relative">
                <label className="block text-sm font-medium text-gray-300">Categorías</label>
                <button onClick={() => setDropdownOpen(!isDropdownOpen)} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition flex justify-between items-center text-left">
                    <span>{filters.selectedCategories.length === 0 ? 'Todo' : `${filters.selectedCategories.length} seleccionada(s)`}</span>
                    <ChevronDownIcon />
                </button>
                {isDropdownOpen && (
                    <div ref={dropdownRef} className="absolute z-10 w-full mt-1 bg-gray-800 border border-gray-600 shadow-lg max-h-60 overflow-y-auto">
                         <div className="px-4 py-2 border-b border-gray-700">
                            <label className="flex items-center space-x-2 cursor-pointer">
                                <input type="checkbox" onChange={toggleSelectAllCategories} checked={filters.selectedCategories.length === categories.length} className="h-4 w-4 border-gray-300 text-primary-600 focus:ring-primary-500" />
                                <span>Seleccionar Todo</span>
                            </label>
                        </div>
                        {categories.map(cat => (
                            <div key={cat.id} className="px-4 py-2">
                                <label className="flex items-center space-x-2 cursor-pointer">
                                    <input type="checkbox" checked={filters.selectedCategories.includes(cat.id)} onChange={() => handleCategoryChange(cat.id)} className="h-4 w-4 border-gray-300 text-primary-600 focus:ring-primary-500" />
                                    <span>{cat.name}</span>
                                </label>
                            </div>
                        ))}
                    </div>
                )}
            </div>
            <div>
                 <label htmlFor="concept" className="block text-sm font-medium text-gray-300">Concepto</label>
                 <input type="text" name="concept" placeholder="Filtrar por concepto..." value={filters.concept} onChange={handleFilterChange} className="mt-1 w-full px-3 py-2 bg-gray-700 border border-gray-600 text-gray-300 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition" />
            </div>
        </div>
        
        <div className="flex justify-end mb-4">
            <button onClick={exportToXLSX} className="flex items-center justify-center px-4 py-2 bg-green-600 text-white hover:bg-green-700 transition">
                <DocumentArrowDownIcon />
                <span>Exportar a XLSX</span>
            </button>
        </div>
        
        <div className="overflow-x-auto relative shadow-md">
            <table className="w-full text-sm text-left text-gray-400">
                <thead className="text-xs text-gray-400 uppercase bg-gray-700">
                    <tr>
                        <SortableHeader sortKey="amount" title="Monto" />
                        <SortableHeader sortKey="date" title="Fecha" />
                        <SortableHeader sortKey="categoryName" title="Categoría" />
                        <th scope="col" className="px-6 py-3">Concepto</th>
                    </tr>
                </thead>
                <tbody>
                    {expensesToRender.map((expense, index) => (
                        <tr 
                            key={expense.id} 
                            onClick={() => onEditExpense(filteredAndSortedExpenses[index])}
                            className="bg-gray-800 border-b border-gray-700 hover:bg-gray-600 cursor-pointer"
                        >
                            <td className="px-6 py-4 font-medium text-white whitespace-nowrap">{formatCurrency(expense.amount)}</td>
                            <td className="px-6 py-4">{formatDate(expense.date)}</td>
                            <td className="px-6 py-4">{expense.categoryName}</td>
                            <td className="px-6 py-4">{expense.concept}</td>
                        </tr>
                    ))}
                     {expensesToRender.length === 0 && (
                        <tr>
                            <td colSpan={4} className="text-center py-8 text-gray-500">No se encontraron gastos con los filtros seleccionados.</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    </div>
  );
};

export default History;